# ชุดโค้ดโปรเจกต์แอป "แซม" (SAM Drive Hub) สำหรับสร้างไฟล์ Android (.apk)

ภายในชุดโปรเจกต์นี้ประกอบด้วยโค้ดครบทั้ง **3 รูปแบบ** เพื่อให้คุณเลือกสร้างไฟล์ `.apk` ได้ตามวิธีที่สะดวกที่สุด:

## 1. โฟลเดอร์ `android_studio_project/` (แนะนำ — เปิดใน Android Studio แล้วกด Build APK ได้ทันที)
- **`app/src/main/java/com/sam/drivehub/MainActivity.kt`**: โค้ดภาษา Kotlin เชื่อมต่อระบบสแกนลายนิ้วมือและสแกนใบหน้าของเครื่อง Android จริง (`BiometricPrompt`), รองรับการเลือกไฟล์จากเครื่องเพื่ออัปโหลดเข้า Google Drive, เปลี่ยนไอคอนแอป และเปลี่ยนรูปพื้นหลัง
- **`app/src/main/assets/www/index.html`**: ตัวแอป **แซม** ฉบับสมบูรณ์ที่ฝังอยู่ในตัวแอป
- **`app/src/main/AndroidManifest.xml`**: ตั้งค่าชื่อแอปเป็น `แซม` พร้อมสิทธิ์การใช้งานครบถ้วน
- **วิธีสั่งสร้างไฟล์ `.apk` ใน Android Studio**:
  1. เปิดโปรแกรม **Android Studio** แล้วเลือก **Open** ไปที่โฟลเดอร์ `android_studio_project`
  2. รอให้ Gradle ซิงค์จนเสร็จ จากนั้นไปที่เมนูด้านบน **Build → Build Bundle(s) / APK(s) → Build APK(s)**
  3. จะได้ไฟล์ `app-debug.apk` พร้อมนำไปติดตั้งลงมือถือ Android ได้ทันที

## 2. โฟลเดอร์ `.github/workflows/build-apk.yml` (สั่ง Build APK อัตโนมัติบน GitHub โดยไม่ต้องลงโปรแกรมในคอม)
- เพียงนำไฟล์ในชุดนี้ขึ้น GitHub Repository ของคุณ ระบบ **GitHub Actions** จะคอมไพล์และสร้างไฟล์ `SAM-DriveHub-Android-APK` ให้กดดาวน์โหลดจากแท็บ **Actions** ได้ฟรีทันที

## 3. โฟลเดอร์ `capacitor_project/` และ `flutter_version/`
- **`capacitor_project/`**: สำหรับรันด้วย Node.js + Capacitor (`npm install && npx cap add android && npx cap open android`)
- **`flutter_version/`**: โค้ดโครงสร้างภาษา Dart สำหรับนักพัฒนาที่ต้องการต่อยอดด้วย Flutter (`flutter build apk --release`)
